<?php

return [

    'developer' => [
        'CREATOR'       => 'Muhammad Rifanul Muttaqin.S.Kom',
        'MADE_IN'       => 'Ambulu - Kabupaten - Jember',
        'VERSION'       => 'Ver 2.0',
        'COMPANY'       => 'Al Barr Software (Al Barr Group)',
    ],

    'mode_modul' => [
        'PENGELUARAN_ACTIVE' => 'pengeluaran_active',
        'PENGELUARAN_NON_ACTIVE' => 'pengeluaran_non_active',
    ],

];