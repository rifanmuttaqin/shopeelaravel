
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">

    <div class="alert alert-light">
        <i class="fas fa-info-circle"></i> &nbsp Masukkan nama pelanggan, nama akan di konversi menjadi lowcase saat ditampilkan.
    </div> 

    <form method="post" action="<?php echo e(route('do-cetak-offline')); ?>">
        
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>Nama Pelanggan</label>
            <input type="text" class="form-control" value="" name="nama_pelanggan">
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-info" id="cetakData"> Cetak </button>
        </div>

    </form>
     
    </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

$( document ).ready(function() { });

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\resources\views/cetak-label-offline/index.blade.php ENDPATH**/ ?>