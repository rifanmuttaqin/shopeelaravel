
 
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4>INFOGRAFIS</h4>
    </div>
    <div class="card-body">

    <div class="row">

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-chart-line"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Total Paket Bulan <?php echo e(date('M')); ?> </h4>
          </div>
          <div class="card-body">
            <?php echo e($transaksi_service->getTotalTransaksi()); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-male"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Customer Terbanyak TF Bulan <?php echo e(date('M')); ?> </h4>
          </div>
          <div class="card-body">
            <?php echo e($transaksi_service->getBestCustomer()); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-male"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Total Customer Baru Pada Bulan <?php echo e(date('M')); ?> </h4>
          </div>
          <div class="card-body">
            <?php echo e($customer_service->sumnewCustomer()); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-print"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Jumlah Pesanan Belum Tercetak </h4>
          </div>
          <div class="card-body">
            <?php echo e($transaksi_service->notPrint()); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Pendapatan Bulan <?php echo e(date('M')); ?> </h4>
          </div>
          <div class="card-body">
            <?php echo e($pemasukan); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Pengeluaran Bulan <?php echo e(date('M')); ?> </h4>
          </div>
          <div class="card-body">
            <?php echo e($pengeluaran); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4> Pendapatan Sementara Bulan <?php echo e(date('M')); ?> </h4>
          </div>
          <div class="card-body">
            <?php echo e($pemasukan - $pengeluaran); ?>

          </div>
        </div>
      </div>
    </div>
       
    </div>
        
    </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\resources\views/home/index.blade.php ENDPATH**/ ?>