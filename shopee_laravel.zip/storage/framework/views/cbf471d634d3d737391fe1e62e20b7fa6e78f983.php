
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
      <div class="card">
      <div class="card-header">
            <h4><?php echo e($title); ?></h4>
      </div>
      <div class="card-body">

            <form  method="post" action="<?php echo e(route('beritaacara-store')); ?>" enctype="multipart/form-data">

                  <?php echo csrf_field(); ?>
                  
                    <div class="form-group">
                            <label>Tanggal</label>
                            <input type="text" class="form-control form-control-user" name ="tanggal" id="tanggal" placeholder="">
                            <small> Isi dengan tanggal pelaporan </small>
                            <?php if($errors->has('tanggal')): ?>
                                <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('tanggal')); ?></p></div>
                            <?php endif; ?>
                    </div>

                    <div class="form-group">
                    <label>Detail Kejadian</label>
                    <textarea type="text" class="form-control form-control-user" name ="detail_kejadian" id="detail_kejadian"></textarea>
                    <small> Isi dengan detail kejadian </small>
                    <?php if($errors->has('detail_kejadian')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('detail_kejadian')); ?></p></div>
                    <?php endif; ?>
                    </div>

                    
                    <div class="form-group">
                    <label>Transaksi</label>
                        <select style="width: 100%" class="form-control form-control-user select2-class" name="transaksi_id" id="transaksi_id">
                        </select>
                    </div>

                    <div style="margin:0 auto;text-align:center">
                        <p> Gambar / Foto Pendukung yang dapat dilampirkan</p>
                    </div>
            
                    <!-- Upload Form  -->
                    <div style="margin:0 auto;text-align:center">
                        <div id="upload" style="">
                            <input type="file" name="file" id="file" class="inputfile"/>
                            <label for="file"> &nbsp <i class="fas fa-file-upload"></i> Upload File &nbsp </label>
                            <p id="filename"></p>
                            <p> File Max. 2 MB </p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Nominal Kerugian (Taksiran)</label>
                        <input type="text" class="form-control form-control-user" name ="nominal_kerugian" id="nominal_kerugian" placeholder="">
                        <small> Isi dengan nominal kerugian </small>
                        <?php if($errors->has('nominal_kerugian')): ?>
                            <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('nominal_kerugian')); ?></p></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                    <label>Status Permasalahan</label>
                    <select name="status_masalah" class="form-control">
                            <option value="10">Aktif</option>
                            <option value="20">Pending</option>
                            <option value="30">Selesai</option>
                    </select>
                    <small> Hanya data dengan status Aktif yang terpakai dalam program </small>
                    <?php if($errors->has('status_aktif')): ?>
                            <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('status_aktif')); ?></p></div>
                    <?php endif; ?>
                    </div>
                
                  <div class="form-group">
                  <label>Status Aktif</label>
                  <select name="status_aktif" class="form-control">
                        <option value="1">Aktif</option>
                        <option value="0">Tidak Aktif</option>
                  </select>
                  <small> Hanya data dengan status Aktif yang terpakai dalam program </small>
                  <?php if($errors->has('status_aktif')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('status_aktif')); ?></p></div>
                  <?php endif; ?>
                  </div>

                  <div class="form-group" style="padding-top: 20px">
                        <button type="submit" class="btn btn-info"> Submit </button>
                  </div>


            </form>	
            
      </div>

      </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

$(function () {

    $('#file').change(function() {
        var filename = $('#file').val();
        $('#filename').html(filename);
    })

    $('#tanggal').daterangepicker({
        autoUpdateInput: true,
        singleDatePicker: true,
        format: 'MM/DD/YYYY',
        locale: { cancelLabel: 'Bersihkan' }
    });

    $('#transaksi_id').select2({
        allowClear: true,
        ajax: {
        url: '<?php echo e(route("transaksi-list")); ?>',
        type: "POST",
        dataType: 'json',
            data: function(params) {
                return {
                  "_token": "<?php echo e(csrf_token()); ?>",
                  search: params.term,
                }
            },
            processResults: function (data, page) {
                return {
                results: data
                };
            }
        }
    })

})

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/BeritaAcara\Resources/views/beritaacara/create.blade.php ENDPATH**/ ?>