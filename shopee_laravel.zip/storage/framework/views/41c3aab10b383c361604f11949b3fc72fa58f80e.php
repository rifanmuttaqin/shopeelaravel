
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">

        <form  method="post" action="<?php echo e(route('blast-doblast')); ?>" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
    
            <div style="margin:0 auto;text-align:center">
                <p> Import data xslx sesuai format yg ditentukan </p>
            </div>

            <div class="form-group">
                <label><strong>yang perlu anda perhatikan adalah maximum broadcast message yg diizinkan tidak lebih dari 1000row</strong></label>
            </div>

            <hr>
    
            <!-- Upload Form  -->
            <div style="margin:0 auto;text-align:center">
                <div id="upload" style="">
                    <input type="file" name="file" id="file" class="inputfile" accept="xls,xlsx"/>
                    <label for="file"> &nbsp <i class="fas fa-file-upload"></i> Upload File &nbsp </label>
                    <p id="filename"></p>
                    <p> File Max. 2 MB </p>
                </div>
            </div>
    
            <div style="padding-bottom: 20px">
                <button id="preview" type="button" class="btn btn-info"> Lihat </button>
                <button id="do-blast" type="submit" class="btn btn-info"> Blast </button>
            </div>
    
            </form>
            
            <hr>
    
            <div id="result_data"> </div>
           
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

let table;

$(function () {
    
    $('#file').change(function() {
        var filename = $('#file').val();
        $('#filename').html(filename);
    })

    $('#preview').on('click', function() {
        var file_data = $('#file').prop('files')[0];   
        var form_data = new FormData();                  
        form_data.append('file', file_data);
        form_data.append('_token', "<?php echo e(csrf_token()); ?>");

        $.ajax({
                url: '<?php echo e(route("blast-preview")); ?>',
                dataType: 'text',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,                         
                type: 'post',
                beforeSend: function(){
                    swal('Mohon tunggu sebentar file sedang kami baca .......', { button:false, closeOnClickOutside:false});
                },
                success: function(data){
                    $('#result_data').html(data);
                },
                complete: function(){
                    swal.close();
                }
        });
    });

})

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Promosi\Resources/views/blast/index.blade.php ENDPATH**/ ?>