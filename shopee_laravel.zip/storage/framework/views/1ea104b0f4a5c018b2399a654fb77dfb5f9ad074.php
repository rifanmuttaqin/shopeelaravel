<div style="width: 100%; padding-left: -10px;">
    <div class="table-responsive">
    <table id="table_result" class="table table-bordered data-table display nowrap" style="width:100%">
    <thead style="text-align:center;">
            <tr>
                <th style="width: 30%">Supplier</th>
                <th style="width: 30%">Tanggal Belanja</th>
                <th style="width: 10%">Total Belanja</th>
                <th style="width: 30%">Action</th>
            </tr>
    </thead>
            <?php
                $total_amount = 0;
            ?>
            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->supplier_name); ?></td>
                <td><?php echo e($data->created_at); ?></td>
                <td><?php echo e($data->total_amount); ?></td>
                <td><a class='btn btn-info' href="<?php echo e(route('transaksi-po-detail', $data->id)); ?>"><i class='fas fa-eye'></i></a></td>
            </tr>
            
            <?php
                $total_amount += $data->total_amount;
            ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
            <td colspan="2">Total</td>
            <td><strong><?php echo e($total_amount); ?></strong></td>
    <tbody>
    </tbody>
    </table>
    </div>
</div><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pengeluaran\Resources/views/transaksi_po/render-search.blade.php ENDPATH**/ ?>