
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
      <div class="card">
      <div class="card-header">
            <h4><?php echo e($title); ?></h4>
      </div>
      <div class="card-body">
                  
            <div class="form-group">
                  <label>Nama Produk</label>
                  <input type="text" disabled class="form-control form-control-user" name ="nama_produk" id="nama_produk" value="<?php echo e($data_produk->nama_produk); ?>">
                  <?php if($errors->has('nama_produk')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('nama_produk')); ?></p></div>
                  <?php endif; ?>
            </div>

            <div class="form-group">
                <label>SKU Induk</label>
                <input type="text" disabled class="form-control form-control-user" name ="sku_induk" id="sku_induk" value="<?php echo e($data_produk->sku_induk); ?>">
            </div>

            <div class="form-group">
                  <label>Harga Utama</label>
                  <input type="text" disabled class="form-control" name ="harga" id="harga" value="<?php echo e($data_produk->harga); ?>">
                  <?php if($errors->has('harga')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('harga')); ?></p></div>
                  <?php endif; ?>
            </div>

            <?php if($data_produk->is_grosir): ?>

            <div id="grosir_area">

                <div class="form-row">

                <div class="form-group col-md-6">
                      <label>Harga Grosir 1</label>
                      <input type="text" class="form-control" disabled name ="harga_grosir_satu" value="<?php echo e($data_produk->harga_grosir_satu); ?>" id="harga_grosir_satu" placeholder="">
                </div>

                <div class="form-group col-md-6">
                      <label>Minimal Pengambilan 1</label>
                      <input type="text" class="form-control" disabled name ="minimal_pengambilan_satu" value="<?php echo e($data_produk->minimal_pengambilan_satu); ?>" id="minimal_pengambilan_satu" placeholder="">
                </div>

                </div>

                <div class="form-row">

                <div class="form-group col-md-6">
                      <label>Harga Grosir 2</label>
                      <input type="text" disabled class="form-control" value="<?php echo e($data_produk->harga_grosir_dua); ?>" name ="harga_grosir_dua" id="harga_grosir_dua" placeholder="">
                </div>

                <div class="form-group col-md-6">
                      <label>Minimal Pengambilan 2</label>
                      <input type="text" disabled class="form-control" value="<?php echo e($data_produk->minimal_pengambilan_dua); ?>" name ="minimal_pengambilan_dua" id="minimal_pengambilan_dua" placeholder="">
                </div>

                </div>

            </div>

            <?php endif; ?>


            <div class="form-group">
                  <label>Status</label>
                  <input <?php if(!$data_produk->status_aktif): ?> style=<?php echo e("background-color:#c89f9f"); ?> <?php endif; ?> disabled value="<?php if($data_produk->status_aktif): ?> <?php echo e('AKTIF'); ?> <?php else: ?> <?php echo e('TIDAK AKTIF'); ?> <?php endif; ?>" type="text" class="form-control form-control-user" placeholder="">
            </div>

            <table class="table table-striped" style="width: 50%">
            <tbody>
                  <tr>
                        <td>Dibuat pada</td>
                        <td><?php echo e(date_format($data_produk->created_at,"d F Y H:i:s")); ?></td>
                  </tr>

                  <tr>
                        <td>Terakhir diupdate</td>
                        <td><?php echo e(date_format($data_produk->updated_at,"d F Y H:i:s")); ?></td>
                  </tr>
            </tbody>
            </table>

            <div class="form-group" style="padding-top: 20px">
                  <a class="btn btn-warning" href="<?php echo e(route('produk')); ?>">Kembali</a>
            </div>

            
      </div>

      </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

$(function () {


})

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pemasukan\Resources/views/produk/show.blade.php ENDPATH**/ ?>