
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">
                
    <div class="form-group row">
    <div class="col-sm-12">
        <label><small>Periode</small></label>
        <input type="text" class="form-control" name="dates" id="dates">
        </div>
    </div>
    
    <div class="form-group">
        <div class="form-group">
            <label>Supplier</label>
            <select style="width: 100%" class="form-control form-control-user select2-class" name="supplier_name" id="supplier_name">
            </select>
        </div>
    </div>

    <div class="form-group" style="padding-top: 20px">
        <button id="tampil" class="btn btn-info">Tampil</button>
        <a class="btn btn-warning" href="<?php echo e(route('transaksi-po-list')); ?>">Kembali</a>
    </div>

    <div id="result"></div>

    </div>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

$(function () {

    $('input[name="dates"]').daterangepicker();

    $( "#tampil" ).click(function() {
        $.ajax({
            type:'POST',
            url: '<?php echo e(route("transaksi-po-preview")); ?>',
            data:
            {
              "_token": "<?php echo e(csrf_token()); ?>",
              id : $('#transaksi_id').val(),
              dates : $('#dates').val(),
              supplier_name : $('#supplier_name').val(),
            },
            success:function(data) {
              $('#result').html(data);
            }
        });
    });

    $('#supplier_name').select2({
        allowClear: true,
        placeholder:'Supplier',
        ajax: {
            url: '<?php echo e(route("supplier-list")); ?>',
            type: "POST",
            dataType: 'json',
            data: function(params) {
                return {
                "_token": "<?php echo e(csrf_token()); ?>",
                search: params.term,
                }
            },
            processResults: function (data, page) {
                return {
                results: data
                };
            }
        }
    })

})

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pengeluaran\Resources/views/transaksi_po/search.blade.php ENDPATH**/ ?>