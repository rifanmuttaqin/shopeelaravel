
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">
        
        <div style="padding-bottom: 20px">
            <a  href="<?php echo e(route('transaksi')); ?>" type="button" class="btn btn-info"> Import Transaksi Baru </a>
            <a href="<?php echo e(route('report-transaksi')); ?>" type="button" class="btn btn-info float-right"> <i class="fas fa-search"></i> &nbsp Pencarian Lanjutan </a>
        </div>

        <div style="width: 100%; padding-left: -10px;">
        <div class="table-responsive">
        <table id="table_result" class="table table-bordered data-table display nowrap" style="width:100%">
        <thead style="text-align:center;">
            <tr>
                <th>Nomor Resi</th>
                <th>Username</th>
                <th>Nama Penerima</th>
                <th>Nomor Pesanan</th>
                <th>Tanggal Pesanan</th>
                <th>Jasa Kirim</th>
                <th style="width: 30%">Aksi</th>
            </tr>
        </thead>
        </table>
        </div>
        </div>

        <hr>
        
        <div class="alert alert-light">
            <small> Hanya menampilkan 100 transaksi terakhir | Pencarian spesifik transaksi bedasarkan periode dapat diakses melalui tombol pencarian &nbsp <i class="fas fa-search"></i></small>
        </div>  
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

let table;

function btnDel(id)
{
    idtransaksi = id;

    swal({
        title: "Menghapus data",
        text: 'Data order yang telah dihapus tidak dapat dikembalikan kembali', 
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
    .then((willDelete) => {
    if (willDelete) {
        $.ajax({
        type:'POST',
        url: '<?php echo e(route("transaksi-destroy")); ?>',
        data:{
            idtransaksi:idtransaksi, 
            "_token": "<?php echo e(csrf_token()); ?>",},
        success:function(data) {
            
            if(data.status != false)
            {
                swal(data.message, { button:false, icon: "success", timer: 1000});
            }
            else
            {
                swal(data.message, { button:false, icon: "error", timer: 1000});
            }

            table.ajax.reload();
        },
        error: function(error) {
            swal('Terjadi kegagalan sistem', { button:false, icon: "error", timer: 1000});
        }
        });      
    }
    });
}

$(function () {

    table = $('#table_result').DataTable({
    processing: true,
    serverSide: true,
    ordering:false,
    aoColumnDefs: [
        { "bSortable": false}
    ],
    rowReorder: {
        selector: 'td:nth-child(2)'
    },
    responsive: true,
    ajax: "<?php echo e(route('listpage-transaksi')); ?>",
    columns: [
        {data: 'no_resi', name: 'no_resi'},
        {data: 'username_pembeli', name: 'username_pembeli'},
        {data: 'nama_pembeli', name: 'nama_pembeli'},
        {data: 'no_pesanan', name: 'no_pesanan'},
        {data: 'tgl_pesanan_dibuat', name: 'tgl_pesanan_dibuat'},
        {data: 'jasa_kirim', name: 'jasa_kirim'},            
        {data: 'action', name: 'action', orderable: false, searchable: false},
    ]
    });

})

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\resources\views/transaksi/listpage.blade.php ENDPATH**/ ?>