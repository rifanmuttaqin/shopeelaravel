<div class="footer-left">
    <p class="love"><?php echo e(config('appinfo.developer.COMPANY')); ?></p>
</div>
<div class="footer-right">
    <?php echo e(config('appinfo.developer.VERSION')); ?>

</div><?php /**PATH C:\laragon\www\shopeelaravel\resources\views/include/footer.blade.php ENDPATH**/ ?>