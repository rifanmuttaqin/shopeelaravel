
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
      <div class="card">
      <div class="card-header">
            <h4><?php echo e($title); ?></h4>
      </div>
      <div class="card-body">
        
        <div class="row">
          <div class="col-sm">
            <div class="form-group">
                <label>Tanggal : </label>
                <input type="text" disabled class="form-control form-control-user" value="<?php echo e($main_transaksi->date); ?>">
            </div>
          </div>
          <div class="col-sm">
            <div class="form-group">
                <label>Kepada Kak : </label>
                <input type="text" disabled class="form-control form-control-user" value="<?php echo e($main_transaksi->nama_customer); ?>">
            </div>
          </div>
          
        </div>

        <table class="table">
            <thead>
              <tr>
                <th scope="col">Nama Produk</th>
                <th scope="col">Jumlah</th>
                <th scope="col">Harga</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transkasi_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->nama_produk); ?></td>
                    <td><?php echo e($data->qty_beli); ?></td>
                    <td><?php echo e($data->harga_produk); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

        <div class="form-row">
            <div class="form-group col-md-2">
                <label>Diskon didapat</label>
                <input type="text" disabled class="form-control form-control-user" value="<?php echo e($main_transaksi->discount_amount); ?>">
            </div>
            <div class="form-group col-md-8">
                <label>Total Belanja</label>
                <input type="text" disabled class="form-control form-control-user" value="<?php echo e($main_transaksi->total_amount); ?>">
            </div>
            <div class="form-group col-md-2">
              <label>LUNAS/BELUM</label>
              <input type="text" disabled class="form-control form-control-user" value="<?php echo e($status_transaksi); ?>">
          </div>
        </div>

        <div class="form-group" style="padding-top: 20px">
            <a class="btn btn-warning" href="<?php echo e(route('transaksi-offline-list')); ?>">Kembali</a>
        </div>
            
      </div>

      </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pemasukan\Resources/views/transaksi/detail.blade.php ENDPATH**/ ?>