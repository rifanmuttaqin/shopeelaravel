
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">
        <p> Pada fitur ini, anda dapat mengakses riwayat pencetakan terakhir, dapat bermanfaat apabila anda perlu mencetak ulang label pengiriman.
        <p style="color:blue"> List history cetak ini akan dihapus secara berkala sejak 3 hari dari pencetakan </p>
    </div>
    </div>

    <div class="card">
    <div class="card-body">

        <div style="width: 100%; padding-left: -10px;">
            <div class="table-responsive">
                <table id="history_table" class="table table-bordered data-table display nowrap" style="width:100%">
                    <thead style="text-align:center;">
                        <tr>
                            <th>Filter Tanggal</th>
                            <th>Toko</th>
                            <th>Dicetak Pada</th>
                            <th style="width: 10%">Cetak Ulang</th>
                        </tr>
                    </thead>
                    <tbody>
                </tbody>
                </table>
            </div>
        </div>
        
        
    </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>
 

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

function btnPrint(id)
{
    var url = '<?php echo e(route("do-cetak-history", ":id")); ?>';
    url     = url.replace(':id', id);
    window.location.replace(url);
}

$(function () {

    // Datatables
    table = $('#history_table').DataTable({
        processing: true,
        serverSide: true,
        ordering: false,
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: true,
        ajax: "#",
        columns: [
            {data: 'date_range', name: 'date_range'},
            {data: 'user_toko_id', name: 'user_toko_id'},
            {data: 'created_at', name: 'created_at'},
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ]
    });

});

</script>
 
 <?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\resources\views/history-cetak/index.blade.php ENDPATH**/ ?>