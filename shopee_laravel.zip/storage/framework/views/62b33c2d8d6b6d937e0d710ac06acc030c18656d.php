
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">

    <div class="form-group row">
    <div class="col-sm-12">
      <label><small>Periode Transaki (Pilih periode tanggal)</small></label>
        <input type="text" class="form-control" name="dates" id="dates">
      </div>
    </div>

    <div style="padding-bottom: 20px">
        <button id="preview" type="button" class="btn btn-info"> <i class="fas fa-search"></i> Proses </button>
    </div>

    <hr>

    <div id='result_data'></div>
           
    </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

function cb(start, end) {
    $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
}

$(function() {
    
    var start = moment().subtract(29, 'days');
    var end = moment();

    $('input[name="dates"]').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);


    $('#preview').click(function() {
        
        $('#result_data').html(null);

        $.ajax({
            url: '<?php echo e(route("laba-rugi-preview")); ?>',
            data:
            {
                "_token": "<?php echo e(csrf_token()); ?>",
                dates : $('#dates').val(),
            },                       
            type: 'post',
            beforeSend: function(){
                swal('Mohon tunggu sebentar data kami proses .......', { button:false, closeOnClickOutside:false});
            },
            success: function(data){
                $('#result_data').html(data);
            },
            complete: function(){
                swal.close();
            }
      });
    
    });


});


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\resources\views/laba-rugi/index.blade.php ENDPATH**/ ?>