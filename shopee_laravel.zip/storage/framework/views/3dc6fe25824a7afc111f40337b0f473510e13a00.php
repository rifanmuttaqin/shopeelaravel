
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">

        <form  method="post" action="<?php echo e(route('transaksi-po-store')); ?>" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        
        <div class="row">
            
            <div class="form-group col-sm text-right">
                <div class="card">
                    <div class="card-body">
                        <h1 class="total_amount"> 0 </h1>
                    </div>
                  </div>
            </div>

            <div class="form-group col-sm">
                <label><?php echo app('translator')->get('Tanggal'); ?></label>
                <input type="text" class="form-control form-control-user" name ="date" id="date" placeholder="">
                <?php if($errors->has('date')): ?>
                    <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('date')); ?></p></div>
                <?php endif; ?>
            </div>
            <div class="form-group col-sm">
                <div class="form-group">
                    <label>Supplier</label>
                    <select style="width: 100%" class="form-control form-control-user select2-class" name="supplier_name" id="supplier_name">
                    </select>
                    <?php if($errors->has('supplier_name')): ?>
                            <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('supplier_name')); ?></p></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <input type="hidden" name="produk_chart" id="produk_chart">

        <div class="form-row">
            <div class="form-group col-md-6">
                <div class="form-group">
                    <label>Produk</label>
                    <select style="width: 100%" class="form-control form-control-user select2-class" name="nama_produk" id="nama_produk">
                    </select>
                </div>
            </div>

            <div class="form-group col-md-4">
                <label>QTY</label>
                <input type="number" class="form-control form-control-user" id="qty_beli">
            </div>

            <div class="form-group col-md-2">
                <div style="padding-top: 30px">
                    <button type="button" id="add_chart" class="btn btn-info"> <i class="fas fa-plus-square"></i> </button>
                </div>
            </div>
        </div>
        
        <div id="temp_table">
        <div style="width: 100%; padding-left: -10px;">
            <div class="table-responsive">
            <table id="table_result" class="table table-bordered data-table display nowrap" style="width:100%">
            <thead style="text-align:center;">
                    <tr>
                        <th style="width: 30%">Barang</th>
                        <th style="width: 30%">Harga</th>
                        <th style="width: 10%">Qty</th>
                        <th style="width: 30%">Total</th>
                        <th style="width: 30%">Action</th>
                    </tr>
            </thead>
                <tr>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>                    
                </tr>
            <tbody>
            </tbody>
            </table>
            </div>
        </div>
        </div>
        <div class="form-row total" style="padding-top: 10px">
            <div class="form-group col-md-6">
            </div>
            <div class="form-group col-md-6">
                <label>Total</label>
                <input type="text" disabled class="form-control form-control-user" value="0">
            </div>
        </div>

        <div class="form-row" style="padding-top: 10px">
            <div class="form-group col-md-6"></div>
            <div class="form-group col-md-6">
                <label>Extra Biaya</label>
                <input onkeyup="setDiskon()" type="text" class="form-control form-control-user" name ="extra_amount" id="extra_amount">
                <?php if($errors->has('extra_amount')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('extra_amount')); ?></p></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-row" style="padding-top: 10px">
            <div class="form-group col-md-6"></div>
            <div class="form-group col-md-6">
                <label>Diskon</label>
                <input onkeyup="setDiskon()" type="text" class="form-control form-control-user" name ="discount_amount" id="discount_amount">
                <?php if($errors->has('discount_amount')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('discount_amount')); ?></p></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-row" style="padding-top: 10px">
            <div class="form-group col-md-6"></div>
            <div class="form-group col-md-6">
                <label>Total Bayar</label>
                <input readonly type="text" class="form-control form-control-user" name ="total_amount" id="total_amount">
                <?php if($errors->has('total_amount')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('total_amount')); ?></p></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label for="formFile" class="form-label">Nota Pembelian</label>
            <input class="form-control" type="file" accept="image/*" id="nota" name="nota">
            <?php if($errors->has('nota')): ?>
                    <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('nota')); ?></p></div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label>Keterangan</label>
            <textarea class="form-control form-control-user" name ="keterangan" id="keterangan"></textarea>
        </div>

        <div class="form-group" style="padding-top: 20px">
            <button type="submit" class="btn btn-info"> Proses </button>
        </div>

        </form>

        </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

let table_result;
let array_chart = [];

function setDiskon() {
    var myEle = document.getElementById("total_amount_real");
    if(myEle){
        
        let diskon = Number($('#discount_amount').val());
        let real_amount = Number($('#total_amount_real').val());
        let extra_amount = Number($('#extra_amount').val());
        let total = (real_amount+extra_amount)-diskon;

        $('#total_amount').val(total);
        $('.total_amount').text(total);
    }   
}

function setFormProduk(param) {
    $('#produk_chart').val(param);
    $('#total_amount').val($('#total_amount_real').val());
    $('.total_amount').text($('#total_amount_real').val());
}

function clearProdukForm() {
    $("#nama_produk").val(null).trigger('change');
    $("#qty_beli").val(null);
    $('.total').hide();
}

function deleteArray(param)
{
    array_chart.splice(param, 1);
    request = $.ajax({
        url: "<?php echo e(route('transaksi-po-addchart')); ?>",
        type: "post",
        data: {array_chart,"_token": "<?php echo e(csrf_token()); ?>"}
    });

    request.done(function (response, textStatus, jqXHR){
        $('#temp_table').html(response);
        setFormProduk(array_chart);
    });
}

$(function () { 

    // ----- ADD CHART CLICK ------
    $( "#add_chart" ).click(function() {
        let produk = $('#nama_produk').select2('data');
        let qty = $('#qty_beli').val();
        
        array_chart.push(JSON.stringify({'nama_produk':produk[0].text,'qty':qty,'total_price':produk[0].price}));
        
        request = $.ajax({
            url: "<?php echo e(route('transaksi-po-addchart')); ?>",
            type: "post",
            data: {array_chart,"_token": "<?php echo e(csrf_token()); ?>"}
        });

        request.done(function (response, textStatus, jqXHR){
            $('#temp_table').html(response);
            setFormProduk(array_chart);
            clearProdukForm();
        });

        return false;
    });

    $('#nama_produk').select2({
        allowClear: true,
        placeholder:'Produk',
        ajax: {
            url: '<?php echo e(route("produkpo-list")); ?>',
            type: "POST",
            dataType: 'json',
            data: function(params) {
                return {
                "_token": "<?php echo e(csrf_token()); ?>",
                search: params.term,
                }
            },
            processResults: function (data, page) {
                return {
                results: data
                };
            }
        }
    })
    
    $('#date').daterangepicker({
        autoUpdateInput: true,
        singleDatePicker: true,
        locale: {cancelLabel: 'Bersihkan',format: "D MMMM Y"}
    });

    $('#supplier_name').select2({
        allowClear: true,
        placeholder:'Supplier',
        ajax: {
            url: '<?php echo e(route("supplier-list")); ?>',
            type: "POST",
            dataType: 'json',
            data: function(params) {
                return {
                "_token": "<?php echo e(csrf_token()); ?>",
                search: params.term,
                }
            },
            processResults: function (data, page) {
                return {
                results: data
                };
            }
        }
    })
})


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pengeluaran\Resources/views/transaksi_po/index.blade.php ENDPATH**/ ?>