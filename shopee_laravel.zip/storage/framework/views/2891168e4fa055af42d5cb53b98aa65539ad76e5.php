<div style="width: 100%; padding-left: -10px;">
    <div class="table-responsive">
    <table id="table_result" class="table table-bordered data-table display nowrap" style="width:100%">
    <thead style="text-align:center;">
            <tr>
                <th style="width: 30%">Barang</th>
                <th style="width: 30%">Harga</th>
                <th style="width: 10%">Qty</th>
                <th style="width: 30%">Total</th>
                <th style="width: 30%">Action</th>
            </tr>
    </thead>
      
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data_produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data_produk['nama_produk']); ?></td>
                <td><?php echo e($data_produk['total_price']); ?></td>
                <td><?php echo e($data_produk['qty']); ?></td>
                <td><?php echo e($data_produk['total']); ?></td> 
                <td><a class='btn btn-info' onclick="deleteArray(<?php echo e($key); ?>)"><i class='fas fa-trash'></i></a></td>  
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
    <tbody>
    </tbody>
    </table>
    </div>
    <div class="form-row" style="padding-top: 10px">
        <div class="form-group col-md-6">
        </div>
        <div class="form-group col-md-6">
            <label>Total</label>
            <input type="text" disabled class="form-control form-control-user" value="<?php echo e($total_amount); ?>" name ="total_amount_real" id="total_amount_real">
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pengeluaran\Resources/views/transaksi_po/render-table.blade.php ENDPATH**/ ?>