
 
<?php $__env->startSection('title', '<?php echo e($title); ?>'); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
  <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
    <div class="card-header">
        <h4><?php echo e($title); ?></h4>
    </div>
    <div class="card-body">

        <div class="alert alert-light">
            <small>Tips : Transaksi lain digunakan untuk mencatat pemasukan lain tanpa list produk, ex: (Dari bonus tips customer dll).</small>
        </div>  

        <form  method="post" action="<?php echo e(route('transaksi-offline-other-store')); ?>" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        
        <div class="form-group">
            <div class="form-group">
                <label>Customer</label>
                <select style="width: 100%" class="form-control form-control-user select2-class" name="nama_customer" id="nama_customer">
                </select>
                <?php if($errors->has('nama_customer')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('nama_customer')); ?></p></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label>Total Belanja</label>
                <input onkeyup="setDiskon()" type="text" id="total_belanja" class="form-control form-control-user" value="0">
            </div>
               
            <div class="form-group col-md-6">
                <label>Diskon</label>
                <input onkeyup="setDiskon()" type="text" class="form-control form-control-user" name ="discount_amount" id="discount_amount">
                <?php if($errors->has('discount_amount')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('discount_amount')); ?></p></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-row" style="padding-top: 10px">
            <div class="form-group col-md-6"></div>
            <div class="form-group col-md-6">
                <label>Total Bayar</label>
                <input readonly type="text" class="form-control form-control-user" name ="total_amount" id="total_amount">
                <?php if($errors->has('total_amount')): ?>
                        <div><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('total_amount')); ?></p></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label for="sel1" style="color: rgb(85, 82, 82)"><strong>Keterangan</strong></label>
            <input type="text" id="keterangan" name="keterangan" class="form-control form-control-user">
        </div>


        <div class="form-group">
            <label for="sel1" style="color: rgb(85, 82, 82)"><strong>Status Pembayaran</strong></label>
            <select class="form-control" id="status_transaksi" name="status_transaksi">
                <option value="10"> LUNAS </option>
                <option value="20"> BELUM LUNAS </option>                         
            </select>
        </div>
       

        <div class="form-group" style="padding-top: 20px">
            <button type="submit" class="btn btn-info"> Proses </button>
        </div>

        </form>

        </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

function setDiskon() {
    
    var myEle = document.getElementById("total_belanja");

    if(myEle){
        let diskon = $('#discount_amount').val();
        let real_amount = $('#total_belanja').val();
        $('#total_amount').val(real_amount-diskon);
    }   

}

$(function () { 

    $('#nama_customer').select2({
        allowClear: true,
        placeholder:'Pelanggan',
        ajax: {
            url: '<?php echo e(route("customer-offline-list")); ?>',
            type: "POST",
            dataType: 'json',
            data: function(params) {
                return {
                "_token": "<?php echo e(csrf_token()); ?>",
                search: params.term,
                }
            },
            processResults: function (data, page) {
                return {
                results: data
                };
            }
        }
    })

})

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shopeelaravel\Modules/Pemasukan\Resources/views/transaksi/other.blade.php ENDPATH**/ ?>