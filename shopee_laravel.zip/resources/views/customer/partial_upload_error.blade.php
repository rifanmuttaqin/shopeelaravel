<div class="alert alert-danger" role="alert">
      File gagal diupload mohon maaf atas ketidak nyamananya, mohon diulang kembali proses upload | Pastikan file yang anda upload berformat benar
</div>