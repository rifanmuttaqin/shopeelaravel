<div class="alert alert-info" role="alert">
      File berhasil diupload Silahkan cek kembali status dari customer | Tunggu Notifikasi Oleh Sistem Apabila Proses Berhasil | Ulangi Jika Status User Tidak Berubah
</div>