<div class="footer-left">
    <p class="love">{{ config('appinfo.developer.COMPANY')}}</p>
</div>
<div class="footer-right">
    {{ config('appinfo.developer.VERSION') }}
</div>