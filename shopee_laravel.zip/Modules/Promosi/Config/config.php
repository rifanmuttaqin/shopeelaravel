<?php

return [
    'name' => 'Promosi'
];
