<?php

return [
    'name' => 'BeritaAcara'
];
