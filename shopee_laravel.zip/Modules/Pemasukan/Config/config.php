<?php

return [
    'name' => 'Pemasukan'
];
