<?php

return [
    'name' => 'Pengeluaran'
];
