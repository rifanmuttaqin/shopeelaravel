<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pemasukan\\Providers\\PemasukanServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pemasukan\\Providers\\PemasukanServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);