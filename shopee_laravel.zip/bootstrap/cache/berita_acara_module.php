<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BeritaAcara\\Providers\\BeritaAcaraServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BeritaAcara\\Providers\\BeritaAcaraServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);