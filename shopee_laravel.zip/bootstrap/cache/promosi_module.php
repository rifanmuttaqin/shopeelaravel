<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Promosi\\Providers\\PromosiServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Promosi\\Providers\\PromosiServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);